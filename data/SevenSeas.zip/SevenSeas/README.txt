Empty files created by command "touch" separating Oceans and Seas based on the NOAA article:

- What are the Seven Seas?
https://oceanservice.noaa.gov/facts/sevenseas.html


